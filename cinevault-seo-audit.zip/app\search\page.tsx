// app/search/page.tsx
import Image from "next/image";
import Link from "next/link";
import { discoverMovies, searchTitles } from "@/lib/fetchers";
import type { Metadata } from "next";

export const runtime = "nodejs";
export const revalidate = 60;

export const metadata: Metadata = {
  title: "Search Movies & TV Shows | CineVault",
  description:
    "Search movies, TV shows, anime, cartoons, and entertainment titles on CineVault.",
  alternates: {
    canonical: "/search",
  },
  openGraph: {
    title: "Search Movies & TV Shows | CineVault",
    description:
      "Find movies, TV shows, anime, cartoons, and entertainment titles.",
    url: "/search",
    siteName: "CineVault",
    images: ["/og-image.png"],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Search Movies & TV Shows | CineVault",
    description:
      "Search movies, TV shows, anime, cartoons, and entertainment titles.",
    images: ["/og-image.png"],
  },
};

/* ---------------- helpers ---------------- */

type SP = { [key: string]: string | string[] | undefined };

const getParam = (sp: SP | undefined, k: string) => {
  const v = sp?.[k];
  return Array.isArray(v) ? v[0] ?? "" : v ?? "";
};

const tmdb = (p?: string | null, size = "w342") =>
  p ? `https://image.tmdb.org/t/p/${size}${p}` : null;

type Norm = {
  id: number;
  media: "movie" | "tv";
  title: string;
  year: string;
  poster: string | null;   // can be from poster_path or (fallback) backdrop_path
  href: string;
};

/** movie/tv only; prefer poster; fallback to backdrop; return null for imageless items */
function toNorm(x: any): Norm | null {
  if (!x || x.media_type === "person") return null; // filter people

  const media: "movie" | "tv" = x.media_type === "tv" || x.first_air_date ? "tv" : "movie";
  const title = x.title || x.name || "Untitled";
  const year = String(x.release_date || x.first_air_date || "").slice(0, 4) || "—";

  // prefer poster; fallback to smaller backdrop and crop via CSS object-cover
  const poster =
    tmdb(x.poster_path, "w342") ||
    tmdb(x.backdrop_path, "w780") // a bit wider, but we'll crop to 2:3

  if (!poster) return null; // drop imageless items entirely

  return {
    id: Number(x.id),
    media,
    title,
    year,
    poster,
    href: `/${media}/${x.id}`,
  };
}


function buildHref(nextPage: number, params: { q?: string; year?: number; genreId?: number }) {
  const usp = new URLSearchParams();
  if (params.q) usp.set("q", params.q);
  if (params.year) usp.set("year", String(params.year));
  if (params.genreId) usp.set("genre", String(params.genreId));
  usp.set("page", String(nextPage));
  return `/search?${usp.toString()}`;
}

/* ---------------- page ---------------- */

type PageProps = {
  searchParams?: Promise<SP>;
};

const categories = [
  { name: "Action", id: 28 },
  { name: "Adventure", id: 12 },
  { name: "Animation", id: 16 },
  { name: "Comedy", id: 35 },
  { name: "Crime", id: 80 },
  { name: "Drama", id: 18 },
  { name: "Fantasy", id: 14 },
  { name: "Horror", id: 27 },
  { name: "Mystery", id: 9648 },
  { name: "Romance", id: 10749 },
  { name: "Sci-Fi", id: 878 },
  { name: "Thriller", id: 53 },
];

export default async function SearchPage({ searchParams }: PageProps) {
  const sp = (await searchParams) ?? {};

  const qRaw = getParam(sp, "q");
  const yearStr = getParam(sp, "year");
  const genreStr = getParam(sp, "genre");
  const pageStr = getParam(sp, "page");

  const q = qRaw.trim();
  const year = yearStr ? Number(yearStr) : undefined;
  const genreId = genreStr ? Number(genreStr) : undefined;
  const page = Math.max(1, Number(pageStr || "1") || 1);

  // fetch
  let data: any = null;
  try {
    data = q ? await searchTitles(q, page) : await discoverMovies({ year, genreId, page });
  } catch {
    data = { results: [], total_pages: 1 };
  }

  const raw: any[] = Array.isArray(data?.results) ? data.results : [];

  // normalize, filter, and cap to keep the grid light
  const items: Norm[] = raw
    .map(toNorm)
    .filter((x): x is Norm => !!x)
    .sort((a, b) => (b.poster ? 1 : 0) - (a.poster ? 1 : 0))
    .slice(0, 40);

  const totalPages = Math.min(Number(data?.total_pages || 1), 500);
  const hasPrev = page > 1;
  const hasNext = page < totalPages;

  return (
    <main className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="mb-6 text-2xl font-semibold">
        {q ? `Results for “${q}”` : "Discover Movies"}
      </h1>

      {!q && (
        <div className="mb-8 flex flex-wrap gap-3">
          {categories.map((cat) => (
            <Link
              key={cat.id}
              href={`/search?genre=${cat.id}`}
              className={`rounded-full border px-4 py-2 text-sm font-bold transition ${
                genreId === cat.id
                  ? "border-yellow-400 bg-yellow-400 text-black"
                  : "border-yellow-400/60 text-yellow-300 hover:bg-yellow-400 hover:text-black"
              }`}
            >
              {cat.name}
            </Link>
          ))}
        </div>
      )}

      {items.length === 0 ? (
        <div className="rounded-2xl border border-zinc-200 p-8 text-center">
          <p className="text-lg font-medium">No titles found.</p>
          <p className="mt-2 text-sm text-zinc-600">
            Try a different search, clear filters, or choose another page.
          </p>
          <div className="mt-4">
            <Link
              href="/search"
              className="inline-block rounded-xl border px-4 py-2 text-sm hover:bg-zinc-50"
            >
              Clear filters
            </Link>
          </div>
        </div>
      ) : (
        <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {items.map((it) => (
            <li key={`${it.media}-${it.id}`} className="group">
              <Link
                href={it.href}
                className="block overflow-hidden rounded-xl border border-zinc-200 transition hover:-translate-y-0.5 hover:shadow"
                prefetch
              >
                <div className="relative aspect-[2/3] bg-white/5">
                  {it.poster ? (
                    <img
                      src={it.poster}
                      alt={it.title}
                      loading="lazy"
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="absolute inset-0 grid place-items-center text-xs text-white/60">
                      No poster
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="line-clamp-2 text-sm font-medium">{it.title}</h3>
                  <p className="mt-1 text-xs text-zinc-600">
                    {it.year} • {it.media.toUpperCase()}
                  </p>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}

      {/* pagination */}
      <div className="mt-8 flex items-center justify-between">
        <Link
          aria-disabled={!hasPrev}
          href={hasPrev ? buildHref(page - 1, { q, year, genreId }) : "#"}
          className={`rounded-xl border px-4 py-2 text-sm ${
            hasPrev ? "hover:bg-zinc-50" : "pointer-events-none opacity-40"
          }`}
        >
          ← Prev
        </Link>
        <span className="text-sm text-zinc-600">
          Page {page} of {totalPages}
        </span>
        <Link
          aria-disabled={!hasNext}
          href={hasNext ? buildHref(page + 1, { q, year, genreId }) : "#"}
          className={`rounded-xl border px-4 py-2 text-sm ${
            hasNext ? "hover:bg-zinc-50" : "pointer-events-none opacity-40"
          }`}
        >
          Next →
        </Link>
      </div>
    </main>
  );
}
