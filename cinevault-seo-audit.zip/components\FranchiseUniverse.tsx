"use client";

import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useEffect, useRef, useState } from "react";

export default function FranchiseUniverse() {
  const rowRef = useRef<HTMLDivElement>(null);

  const [franchises, setFranchises] = useState<
    { name: string; image: string | null }[]
  >([]);

  useEffect(() => {
    async function loadFranchises() {
      const res = await fetch("/api/franchises");
      const data = await res.json();
      setFranchises(data);
    }

    loadFranchises();
  }, []);

  function scroll(dir: "left" | "right") {
    rowRef.current?.scrollBy({
      left: dir === "left" ? -500 : 500,
      behavior: "smooth",
    });
  }

  return (
    <section className="relative overflow-hidden rounded-[32px] border border-white/10 bg-white/[0.045] p-6 shadow-[0_20px_80px_rgba(0,0,0,0.35)] backdrop-blur-xl md:p-8">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(250,204,21,0.15),transparent_35%)]" />

      <div className="relative mb-6 flex items-end justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.35em] text-yellow-400">
            Cinematic Universes
          </p>

          <h2 className="mt-2 text-3xl font-black md:text-5xl">
            Legendary Franchises
          </h2>

          <p className="mt-3 max-w-3xl text-white/60">
            Explore the biggest movie worlds, sagas, superheroes, fantasy
            realms, animation universes, and horror collections.
          </p>
        </div>

        <div className="hidden gap-2 md:flex">
          <button
            onClick={() => scroll("left")}
            className="rounded-full border border-white/10 bg-black/40 p-3 hover:bg-yellow-400 hover:text-black"
          >
            <ChevronLeft />
          </button>

          <button
            onClick={() => scroll("right")}
            className="rounded-full border border-white/10 bg-black/40 p-3 hover:bg-yellow-400 hover:text-black"
          >
            <ChevronRight />
          </button>
        </div>
      </div>

      <div
        ref={rowRef}
        className="relative flex gap-4 overflow-x-auto pb-3 hide-scrollbar"
      >
        {franchises.map((f) => (
          <Link
            key={f.name}
            href={`/search?q=${encodeURIComponent(f.name)}`}
            className="group min-w-[190px] rounded-3xl border border-white/10 bg-black/30 p-5 transition hover:-translate-y-1 hover:border-yellow-400/60 hover:bg-white/10"
          >
            <div className="relative mb-4 h-28 overflow-hidden rounded-2xl bg-white/5">
              {f.image ? (
                <img
                  src={f.image}
                  alt={f.name}
                  className="h-full w-full object-cover transition duration-500 group-hover:scale-110"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-white/5 text-xs text-white/40">
                  No image
                </div>
              )}

              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
            </div>

            <h3 className="line-clamp-2 min-h-[44px] text-lg font-black leading-tight">
              {f.name}
            </h3>

            <p className="mt-2 text-xs text-white/45 group-hover:text-yellow-300">
              Explore universe
            </p>
          </Link>
        ))}
      </div>
    </section>
  );
}